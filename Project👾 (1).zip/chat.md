# WhatsApp Chat Export: Project👾
Export date: September 29, 2026 at 2:37 AM

---

## September 27, 2026

[1:54 AM] __+91 70921 75732 created the group__

[1:54 AM] __+91 70921 75732 added You__

[1:57 AM] __+91 99439 84363 added +91 96595 94290__

[1:59 AM] __+91 70921 75732 changed the group name to 'Project👾'__

[1:59 AM] **+91 70921 75732:** La

[1:59 AM] **+91 70921 75732:** Elarm

[1:59 AM] **+91 99439 84363:** Slu la

[2:01 AM] **+91 70921 75732:** [Voice message]

[2:03 AM] **+91 99439 84363:**
> _+91 70921 75732: Voice message_
Ok la wait check panitu

[2:06 AM] **+91 70921 75732:** Ah

[2:16 AM] **+91 99439 84363:** [Image]

[2:16 AM] **+91 99439 84363:** [Image]

[2:17 AM] **+91 70921 75732:** Ah ok la crctuh

[2:17 AM] **+91 99439 84363:**
> _+91 70921 75732: Ah ok la crctuh_
Haa ok laa

[2:18 AM] **+91 70921 75732:** Priya rakshana anupungola🙏

[2:18 AM] **+91 99439 84363:**
> _+91 70921 75732: Priya rakshana anupungola🙏_
😂😂panuvanga laa

[2:18 AM] **+91 70921 75732:** 😭

[2:18 AM] **+91 70921 75732:** [Voice message]

[2:19 AM] **+91 99439 84363:**
> _+91 70921 75732: Voice message_
Ne eppdi voice msg pota oodane net on pani snd pana maatanga varum po varuvanga la loosu

[2:19 AM] **+91 70921 75732:** Okla😪

[2:56 AM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[9:18 AM] **+91 99439 84363:** _This message was deleted_

[9:18 AM] **+91 99439 84363:** _This message was deleted_

[9:18 AM] **+91 99439 84363:** _This message was deleted_

---

## September 29, 2026

[2:12 AM] **+91 70921 75732:** [Voice message]

[2:27 AM] **+91 99439 84363:** SWTID-2026-9797

Naama team ID

[2:27 AM] **+91 99439 84363:**
> _+91 99439 84363: SWTID-2026-9797

Naama team ID_
Ithu thaan nama team ID guyss

[2:30 AM] **+91 70921 75732:** https://drive.google.com/file/d/1Gs1smBftNkPZGaov9otFT7tvr_BWzTxa/view?usp=drive_link

[2:30 AM] **+91 70921 75732:** demo link

[2:32 AM] **+91 99439 84363:** Ok

[2:47 AM] **+91 70921 75732:** https://github.com/rayeesharaseed123-ops/EduGenie.git

[2:47 AM] **+91 70921 75732:** Files
